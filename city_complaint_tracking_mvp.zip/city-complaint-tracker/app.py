"""
City Complaint Tracking MVP
Run with: python app.py
"""
import os
import re
import json
import random
import string
import sqlite3
import smtplib
import logging
from functools import wraps
from datetime import datetime
from email.message import EmailMessage

from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, session, jsonify, send_from_directory, abort
)
from werkzeug.utils import secure_filename

from config import Config

app = Flask(__name__)
app.config.from_object(Config)

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

logging.basicConfig(level=logging.INFO)
logger = app.logger

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------
def get_db_connection():
    conn = sqlite3.connect(app.config["DATABASE"])
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create the complaints table if it does not already exist."""
    conn = get_db_connection()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS complaints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tracking_id TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT,
            type TEXT NOT NULL,
            location TEXT NOT NULL,
            description TEXT NOT NULL,
            photo_filename TEXT,
            status TEXT NOT NULL DEFAULT 'Submitted',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()
    logger.info("Database initialized (complaints.db ready).")


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------
def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in app.config["ALLOWED_EXTENSIONS"]
    )


def generate_tracking_id():
    """Generate a short, unique, easy-to-type tracking ID like CMP7K92A."""
    conn = get_db_connection()
    while True:
        suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
        tracking_id = f"CMP{suffix}"
        existing = conn.execute(
            "SELECT id FROM complaints WHERE tracking_id = ?", (tracking_id,)
        ).fetchone()
        if not existing:
            conn.close()
            return tracking_id


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def complaint_to_dict(row):
    return {
        "id": row["id"],
        "tracking_id": row["tracking_id"],
        "name": row["name"],
        "email": row["email"],
        "phone": row["phone"] or "",
        "type": row["type"],
        "location": row["location"],
        "description": row["description"],
        "photo_filename": row["photo_filename"],
        "status": row["status"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def login_required(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not session.get("admin_logged_in"):
            flash("Please log in to access the admin dashboard.", "warning")
            return redirect(url_for("admin_login"))
        return view_func(*args, **kwargs)
    return wrapped


# ---------------------------------------------------------------------------
# Email notifications
# ---------------------------------------------------------------------------
def send_status_email(to_email, name, tracking_id, issue_type, location,
                       old_status, new_status, updated_at):
    """
    Attempt to send a status-change notification email via Gmail SMTP.
    Returns (success: bool, error_message: str or None).
    This function must NEVER raise - callers rely on it to fail safely
    so that a failed email never blocks a database status update.
    """
    mail_user = app.config.get("MAIL_USERNAME")
    mail_pass = app.config.get("MAIL_PASSWORD")

    if not mail_user or not mail_pass:
        msg = "Gmail credentials are not configured (MAIL_USERNAME/MAIL_PASSWORD missing)."
        logger.warning(msg)
        return False, msg

    try:
        resolved_note = ""
        if new_status == "Resolved":
            resolved_note = (
                "\nYour complaint has been marked as RESOLVED. "
                "Thank you for helping us improve our city services.\n"
            )

        body = f"""Hello {name},

This is an update regarding your complaint filed with the City Complaint Tracker.

Tracking ID:     {tracking_id}
Issue Type:      {issue_type}
Location:        {location}
Previous Status: {old_status}
New Status:      {new_status}
Updated At:      {updated_at}
{resolved_note}
You can check the latest status at any time using your Tracking ID on the
Track Complaint page.

Thank you,
City Complaint Tracker Team
"""

        msg = EmailMessage()
        msg["Subject"] = f"Complaint {tracking_id} Status Updated"
        msg["From"] = mail_user
        msg["To"] = to_email
        msg.set_content(body)

        with smtplib.SMTP(app.config["MAIL_SERVER"], app.config["MAIL_PORT"], timeout=15) as server:
            server.starttls()
            server.login(mail_user, mail_pass)
            server.send_message(msg)

        logger.info(f"Status email sent to {to_email} for {tracking_id}.")
        return True, None

    except Exception as exc:  # noqa: BLE001 - we intentionally swallow all errors
        logger.error(f"Failed to send status email for {tracking_id}: {exc}")
        return False, str(exc)


# ---------------------------------------------------------------------------
# Resident routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html", issue_types=app.config["ISSUE_TYPES"])


@app.route("/submit", methods=["POST"])
def submit_complaint():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip()
    issue_type = request.form.get("type", "").strip()
    location = request.form.get("location", "").strip()
    description = request.form.get("description", "").strip()
    photo = request.files.get("photo")

    errors = []

    if not name:
        errors.append("Name is required.")
    if not email:
        errors.append("Email is required.")
    elif not EMAIL_REGEX.match(email):
        errors.append("Please enter a valid email address.")
    if issue_type not in app.config["ISSUE_TYPES"]:
        errors.append("Please select a valid issue type.")
    if not location:
        errors.append("Location is required.")
    if not description:
        errors.append("Description is required.")

    photo_filename = None
    if photo and photo.filename:
        if not allowed_file(photo.filename):
            errors.append(
                "Invalid photo format. Allowed types: jpg, jpeg, png, gif, webp."
            )

    if errors:
        for err in errors:
            flash(err, "danger")
        return redirect(url_for("index"))

    # Save the photo only after all validation has passed
    if photo and photo.filename:
        original_name = secure_filename(photo.filename)
        ext = original_name.rsplit(".", 1)[1].lower()
        unique_name = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{random.randint(1000,9999)}.{ext}"
        photo_path = os.path.join(app.config["UPLOAD_FOLDER"], unique_name)
        photo.save(photo_path)
        photo_filename = unique_name

    tracking_id = generate_tracking_id()
    timestamp = now_str()

    conn = get_db_connection()
    conn.execute(
        """
        INSERT INTO complaints
            (tracking_id, name, email, phone, type, location, description,
             photo_filename, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            tracking_id, name, email, phone, issue_type, location, description,
            photo_filename, "Submitted", timestamp, timestamp,
        ),
    )
    conn.commit()
    conn.close()

    return redirect(url_for("success", tracking_id=tracking_id))


@app.route("/success/<tracking_id>")
def success(tracking_id):
    return render_template("success.html", tracking_id=tracking_id)


@app.route("/track", methods=["GET", "POST"])
def track():
    complaint = None
    searched = False
    tracking_id_input = ""

    if request.method == "POST":
        tracking_id_input = request.form.get("tracking_id", "").strip().upper()
        searched = True
        if tracking_id_input:
            conn = get_db_connection()
            row = conn.execute(
                "SELECT * FROM complaints WHERE tracking_id = ?",
                (tracking_id_input,),
            ).fetchone()
            conn.close()
            if row:
                complaint = complaint_to_dict(row)
            else:
                flash(
                    f"No complaint found with tracking ID '{tracking_id_input}'. "
                    "Please check the ID and try again.",
                    "warning",
                )

    return render_template(
        "track.html",
        complaint=complaint,
        searched=searched,
        tracking_id_input=tracking_id_input,
    )


@app.route("/api/track/<tracking_id>")
def api_track(tracking_id):
    conn = get_db_connection()
    row = conn.execute(
        "SELECT * FROM complaints WHERE tracking_id = ?", (tracking_id.strip().upper(),)
    ).fetchone()
    conn.close()

    if not row:
        return jsonify({"success": False, "error": "Tracking ID not found."}), 404

    return jsonify({"success": True, "complaint": complaint_to_dict(row)})


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    safe_name = secure_filename(filename)
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], safe_name)
    if not os.path.isfile(file_path):
        abort(404)
    return send_from_directory(app.config["UPLOAD_FOLDER"], safe_name)


# ---------------------------------------------------------------------------
# Admin routes
# ---------------------------------------------------------------------------
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        if (
            username == app.config["ADMIN_USERNAME"]
            and password == app.config["ADMIN_PASSWORD"]
        ):
            session["admin_logged_in"] = True
            session["admin_username"] = username
            flash("Logged in successfully.", "success")
            return redirect(url_for("admin_dashboard"))

        flash("Invalid username or password.", "danger")
        return redirect(url_for("admin_login"))

    return render_template("admin_login.html")


@app.route("/admin/logout")
def admin_logout():
    session.pop("admin_logged_in", None)
    session.pop("admin_username", None)
    flash("You have been logged out.", "info")
    return redirect(url_for("admin_login"))


@app.route("/admin/dashboard")
@login_required
def admin_dashboard():
    status_filter = request.args.get("status", "All")

    conn = get_db_connection()
    if status_filter and status_filter != "All":
        rows = conn.execute(
            "SELECT * FROM complaints WHERE status = ? ORDER BY created_at DESC",
            (status_filter,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM complaints ORDER BY created_at DESC"
        ).fetchall()

    # Chart data: counts by issue type (always all 4 types, real counts from DB)
    type_counts = {t: 0 for t in app.config["ISSUE_TYPES"]}
    for t in app.config["ISSUE_TYPES"]:
        count_row = conn.execute(
            "SELECT COUNT(*) as cnt FROM complaints WHERE type = ?", (t,)
        ).fetchone()
        type_counts[t] = count_row["cnt"]

    # Chart data: counts by status
    status_counts = {s: 0 for s in app.config["STATUSES"]}
    for s in app.config["STATUSES"]:
        count_row = conn.execute(
            "SELECT COUNT(*) as cnt FROM complaints WHERE status = ?", (s,)
        ).fetchone()
        status_counts[s] = count_row["cnt"]

    total_row = conn.execute("SELECT COUNT(*) as cnt FROM complaints").fetchone()
    total_complaints = total_row["cnt"]

    conn.close()

    complaints = [complaint_to_dict(r) for r in rows]

    return render_template(
        "admin_dashboard.html",
        complaints=complaints,
        status_filter=status_filter,
        statuses=["All"] + app.config["STATUSES"],
        type_labels=json.dumps(list(type_counts.keys())),
        type_values=json.dumps(list(type_counts.values())),
        status_labels=json.dumps(list(status_counts.keys())),
        status_values=json.dumps(list(status_counts.values())),
        total_complaints=total_complaints,
    )


@app.route("/admin/update_status/<int:complaint_id>", methods=["POST"])
@login_required
def update_status(complaint_id):
    new_status = request.form.get("new_status", "").strip()

    conn = get_db_connection()
    row = conn.execute(
        "SELECT * FROM complaints WHERE id = ?", (complaint_id,)
    ).fetchone()

    if not row:
        conn.close()
        flash("Complaint not found.", "danger")
        return redirect(url_for("admin_dashboard"))

    current_status = row["status"]

    if new_status not in app.config["STATUSES"]:
        conn.close()
        flash("Invalid status value.", "danger")
        return redirect(url_for("admin_dashboard"))

    allowed_next = app.config["STATUS_TRANSITIONS"].get(current_status)

    if new_status == current_status:
        conn.close()
        flash("Complaint is already in that status.", "info")
        return redirect(url_for("admin_dashboard"))

    if allowed_next is None or new_status != allowed_next:
        conn.close()
        flash(
            f"Invalid status transition: '{current_status}' → '{new_status}' "
            f"is not allowed. Statuses must progress "
            f"Submitted → In Progress → Resolved.",
            "danger",
        )
        return redirect(url_for("admin_dashboard"))

    updated_at = now_str()

    # Step 1: update the database first - this must succeed independently
    # of whether the notification email succeeds or fails.
    conn.execute(
        "UPDATE complaints SET status = ?, updated_at = ? WHERE id = ?",
        (new_status, updated_at, complaint_id),
    )
    conn.commit()

    resident_email = row["email"]
    resident_name = row["name"]
    tracking_id = row["tracking_id"]
    issue_type = row["type"]
    location = row["location"]

    conn.close()

    flash(
        f"Status for {tracking_id} updated: {current_status} → {new_status}.",
        "success",
    )

    # Step 2: attempt to send the email notification. Failure here is
    # logged and shown as a warning, but never rolls back the update above.
    email_sent, email_error = send_status_email(
        to_email=resident_email,
        name=resident_name,
        tracking_id=tracking_id,
        issue_type=issue_type,
        location=location,
        old_status=current_status,
        new_status=new_status,
        updated_at=updated_at,
    )

    if email_sent:
        flash(f"Notification email sent to {resident_email}.", "success")
    else:
        flash(
            f"Status was updated, but the notification email could not be sent "
            f"({email_error}). Please check the Gmail SMTP configuration in .env.",
            "warning",
        )

    return redirect(url_for("admin_dashboard", status=request.form.get("current_filter", "All")))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
