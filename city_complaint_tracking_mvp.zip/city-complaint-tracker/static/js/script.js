/**
 * City Complaint Tracker - front-end helpers
 *
 * Handles the 30-second auto-refresh of the complaint tracking page.
 * Polls GET /api/track/<tracking_id> and updates the DOM in place
 * (no full page reload).
 */

(function () {
    const REFRESH_INTERVAL_MS = 30000; // 30 seconds

    document.addEventListener("DOMContentLoaded", function () {
        const resultBox = document.getElementById("complaint-result");
        if (!resultBox) {
            return; // No complaint currently displayed - nothing to poll
        }

        const trackingId = resultBox.getAttribute("data-tracking-id");
        if (!trackingId) {
            return;
        }

        setInterval(function () {
            refreshComplaintStatus(trackingId);
        }, REFRESH_INTERVAL_MS);
    });

    function refreshComplaintStatus(trackingId) {
        const refreshErrorEl = document.getElementById("refresh-error");

        fetch(`/api/track/${encodeURIComponent(trackingId)}`)
            .then(function (response) {
                if (!response.ok) {
                    throw new Error("Network response was not OK (" + response.status + ")");
                }
                return response.json();
            })
            .then(function (data) {
                if (!data.success) {
                    throw new Error(data.error || "Unknown error");
                }
                updateComplaintUI(data.complaint);
                if (refreshErrorEl) {
                    refreshErrorEl.classList.add("d-none");
                }
            })
            .catch(function (err) {
                console.error("Auto-refresh failed:", err);
                if (refreshErrorEl) {
                    refreshErrorEl.classList.remove("d-none");
                }
            });
    }

    function updateComplaintUI(complaint) {
        // Status badge
        const statusBadge = document.getElementById("status-badge");
        if (statusBadge) {
            statusBadge.textContent = complaint.status;
            statusBadge.className =
                "badge status-badge status-" +
                complaint.status.replace(/\s+/g, "-").toLowerCase();
        }

        // Updated timestamp
        const updatedAtEl = document.getElementById("updated-at");
        if (updatedAtEl) {
            updatedAtEl.textContent = complaint.updated_at;
        }

        // Other fields that could change over time
        const descriptionEl = document.getElementById("description-text");
        if (descriptionEl) {
            descriptionEl.textContent = complaint.description;
        }

        const locationEl = document.getElementById("location-text");
        if (locationEl) {
            locationEl.textContent = complaint.location;
        }
    }
})();
